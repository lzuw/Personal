# 📮 Colección Postman

## 📄 Archivos

| Archivo | Contenido |
|---|---|
| `bibliotech-api.postman_collection.json` | Colección importable a Postman con todos los endpoints REST |

## Cómo importar

1. Abrir Postman.
2. **File → Import** → seleccionar `bibliotech-api.postman_collection.json`.
3. Aparece la colección "BiblioTech API".
4. Editar la variable `base_url` para apuntar a localhost o producción.

## Variables

| Variable | Valor por defecto |
|---|---|
| `base_url` | `http://localhost:8080` |

Para apuntar a producción, cambiar a `https://bibliotech.onrender.com`.
