# Modelo Relacional — BiblioTech

Descripción textual de cada tabla con sus columnas, tipos y relaciones.

---

## Tabla: `rol`

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| nombre | VARCHAR(50) | NO | | | ADMIN, BIBLIOTECARIO, LECTOR |

---

## Tabla: `usuario`

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| correo | VARCHAR(150) | NO | | | UNIQUE |
| password | VARCHAR(60) | NO | | | BCrypt hash |
| activo | BOOLEAN | NO | | | default true |
| rol_id | BIGINT | NO | | ✅ rol(id) | Rol asignado |
| fecha_registro | DATETIME | NO | | | default NOW() |

---

## Tabla: `lector`

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| usuario_id | BIGINT | NO | | ✅ usuario(id) | UNIQUE, 1:1 con usuario |
| carnet | VARCHAR(20) | NO | | | UNIQUE, número de socio |
| nombre | VARCHAR(100) | NO | | | |
| apellidos | VARCHAR(100) | NO | | | |
| telefono | VARCHAR(20) | SÍ | | | |
| direccion | VARCHAR(255) | SÍ | | | |

---

## Tabla: `bibliotecario`

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| usuario_id | BIGINT | NO | | ✅ usuario(id) | UNIQUE, 1:1 con usuario |
| nombre | VARCHAR(100) | NO | | | |
| codigo_empleado | VARCHAR(50) | NO | | | UNIQUE |
| turno | VARCHAR(20) | SÍ | | | Mañana / Tarde |

---

## Tabla: `categoria`

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| nombre | VARCHAR(50) | NO | | | Novela, Ciencia, Historia, etc. |

---

## Tabla: `autor`

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| nombre | VARCHAR(150) | NO | | | |
| nacionalidad | VARCHAR(80) | SÍ | | | |

---

## Tabla: `libro`

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| titulo | VARCHAR(200) | NO | | | |
| isbn | VARCHAR(20) | SÍ | | | UNIQUE |
| editorial | VARCHAR(100) | SÍ | | | |
| anio_publicacion | INT | SÍ | | | |
| categoria_id | BIGINT | NO | | ✅ categoria(id) | |
| ejemplares_total | INT | NO | | | |
| ejemplares_disponibles | INT | NO | | | |
| fecha_ingreso | DATE | SÍ | | | |
| activo | BOOLEAN | NO | | | default true (soft delete) |

---

## Tabla: `libro_autor` (N:M)

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| libro_id | BIGINT | NO | ✅ | ✅ libro(id) | |
| autor_id | BIGINT | NO | ✅ | ✅ autor(id) | |

PK compuesta: (`libro_id`, `autor_id`)

---

## Tabla: `prestamo` (transaccional)

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| libro_id | BIGINT | NO | | ✅ libro(id) | |
| lector_id | BIGINT | NO | | ✅ lector(id) | |
| bibliotecario_id | BIGINT | NO | | ✅ bibliotecario(id) | Quién lo registró |
| fecha_prestamo | DATE | NO | | | |
| fecha_devolucion_esperada | DATE | NO | | | |
| fecha_devolucion_real | DATE | SÍ | | | NULL hasta devolver |
| estado | VARCHAR(20) | NO | | | ACTIVO, DEVUELTO, VENCIDO, CANCELADO |
| observaciones | TEXT | SÍ | | | Notas del bibliotecario |
| fecha_creacion | DATETIME | NO | | | default NOW() |

---

## Tabla: `multa` (transaccional)

| Columna | Tipo | Nulo | PK | FK | Descripción |
|---|---|---|---|---|---|
| id | BIGINT | NO | ✅ | | Llave primaria |
| prestamo_id | BIGINT | NO | | ✅ prestamo(id) | UNIQUE, 1:1 con préstamo |
| dias_retraso | INT | NO | | | |
| monto | DECIMAL(10,2) | NO | | | días × tarifa diaria |
| pagada | BOOLEAN | NO | | | default false |
| fecha_emision | DATETIME | NO | | | |
