# 🗃️ Diagrama Entidad-Relación

Modelo de la base de datos del sistema BiblioTech.

## 📄 Archivos en esta carpeta

| Archivo | Contenido |
|---|---|
| `diagrama-er.png` | Diagrama visual (placeholder en este ejemplo) |
| `modelo-relacional.md` | Descripción textual de tablas y relaciones |
| `diagrama-er.mwb` | Archivo nativo de MySQL Workbench (opcional) |

## 📊 Resumen del modelo

**10 tablas** (cumple el mínimo requerido por el enunciado):

| # | Tabla | Tipo |
|---|---|---|
| 1 | `usuario` | Entidad principal |
| 2 | `rol` | Catálogo |
| 3 | `lector` | Entidad principal |
| 4 | `bibliotecario` | Entidad principal |
| 5 | `categoria` | Catálogo |
| 6 | `autor` | Entidad principal |
| 7 | `libro` | Entidad principal |
| 8 | `libro_autor` | Tabla puente (N:M entre libro y autor) |
| 9 | `prestamo` | **Transaccional** |
| 10 | `multa` | **Transaccional** (derivada de préstamo) |

> En el repo real, ver `diagrama-er.png` para la representación visual.

## 🔗 Relaciones principales

- `usuario` 1:1 `lector` / `bibliotecario` (un usuario puede ser lector, bibliotecario o admin)
- `categoria` 1:N `libro`
- `libro` N:M `autor` (vía `libro_autor`)
- `libro` 1:N `prestamo`
- `lector` 1:N `prestamo`
- `bibliotecario` 1:N `prestamo`
- `prestamo` 1:1 `multa`

## ✅ Cumplimiento de requisitos

- ✅ **Mínimo 8 tablas:** sí (10)
- ✅ **Relaciones 1:N:** sí (categoria-libro, lector-prestamo)
- ✅ **Relaciones N:M:** sí (libro-autor)
- ✅ **Llaves primarias:** todas las tablas tienen PK
- ✅ **Llaves foráneas:** correctamente definidas
- ✅ **Integridad referencial:** ON DELETE CASCADE en `libro_autor`, ON UPDATE CASCADE en FKs
- ✅ **Tabla transaccional:** `prestamo` y `multa`
