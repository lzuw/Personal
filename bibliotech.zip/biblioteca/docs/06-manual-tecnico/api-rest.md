# API REST — BiblioTech

Documentación de los endpoints REST. La colección Postman está en [`postman/`](../../postman/).

## Base URL

- **Local:** `http://localhost:8080`
- **Producción:** `https://bibliotech.onrender.com`

## Autenticación

Los endpoints `/api/**` requieren Basic Auth o token JWT.

```
Authorization: Basic dXN1YXJpbzpwYXNzd29yZA==
```

---

## Endpoints

### `GET /api/libros`

Lista todos los libros activos del catálogo.

**Request:**
```http
GET /api/libros HTTP/1.1
Authorization: Basic dXN1YXJpbzpwYXNzd29yZA==
```

**Response 200 OK:**
```json
[
  {
    "id": 1,
    "titulo": "Cien anos de soledad",
    "isbn": "9780307474728",
    "categoria": "Novela",
    "anioPublicacion": 1967,
    "ejemplaresDisponibles": 2
  },
  {
    "id": 4,
    "titulo": "Clean Code",
    "isbn": "9780132350884",
    "categoria": "Tecnologia",
    "anioPublicacion": 2008,
    "ejemplaresDisponibles": 1
  }
]
```

**Errores:**
- `401 Unauthorized` — no se envió token / credenciales inválidas.

---

### `POST /api/prestamos`

Registra un nuevo préstamo.

**Request:**
```http
POST /api/prestamos HTTP/1.1
Content-Type: application/json
Authorization: Basic dXN1YXJpbzpwYXNzd29yZA==

{
  "libroId": 1,
  "lectorId": 1,
  "fechaPrestamo": "2025-09-15",
  "fechaDevolucionEsperada": "2025-09-29"
}
```

**Response 201 Created:**
```json
{
  "id": 42,
  "libroId": 1,
  "lectorId": 1,
  "fechaPrestamo": "2025-09-15",
  "fechaDevolucionEsperada": "2025-09-29",
  "estado": "ACTIVO",
  "fechaCreacion": "2025-09-15T14:23:45"
}
```

**Errores:**
- `400 Bad Request` — datos inválidos en el body.
- `409 Conflict` — el libro no tiene ejemplares disponibles.

---

## Pruebas

Importar `postman/bibliotech-api.postman_collection.json` en Postman para probar todos los endpoints con ejemplos.

## Status codes usados

| Código | Significado |
|---|---|
| 200 | OK |
| 201 | Created (POST exitoso) |
| 400 | Bad Request (datos inválidos) |
| 401 | Unauthorized (auth faltante) |
| 403 | Forbidden (sin permisos) |
| 404 | Not Found |
| 409 | Conflict |
| 500 | Internal Server Error |
