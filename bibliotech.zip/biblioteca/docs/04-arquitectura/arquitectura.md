# Arquitectura Técnica — BiblioTech

## Capas del sistema

```
[Cliente (Navegador)] ─HTTP─> [Controller] ─> [Service] ─> [Repository] ─> [MySQL]
                                                                 │
                                                          [Entity Java]
```

### 1. Capa Controller (`controller/`)

Recibe peticiones HTTP, extrae parámetros, llama al Service, devuelve la vista o JSON.

```java
@Controller
@RequestMapping("/libros")
public class LibroController {
    @Autowired private LibroService service;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("libros", service.listarTodos());
        return "libros/lista";
    }
}
```

Responsabilidades:
- Routing de URLs
- Validación de forma de los inputs
- Selección de la vista

NO debe contener: lógica de negocio, queries SQL.

### 2. Capa Service (`service/`)

Lógica de negocio. Coordina llamadas a varios repositories cuando hace falta.

```java
@Service
public class PrestamoService {
    @Autowired private PrestamoRepository prestamoRepo;
    @Autowired private MultaService multaService;

    @Transactional
    public Prestamo registrarDevolucion(Long prestamoId) {
        Prestamo p = prestamoRepo.findById(prestamoId).orElseThrow();
        p.setEstado(EstadoPrestamo.DEVUELTO);
        multaService.generarSiHayAtraso(p);  // efecto secundario
        return prestamoRepo.save(p);
    }
}
```

Responsabilidades:
- Reglas del negocio (estados de préstamo, cálculo de multas, validaciones)
- Transacciones (`@Transactional`)
- Coordinación entre repositories

### 3. Capa Repository (`repository/`)

Interfaces que extienden `JpaRepository`. Spring genera la implementación.

```java
public interface LibroRepository extends JpaRepository<Libro, Long> {
    List<Libro> findByCategoriaIdAndActivoTrue(Long categoriaId);
    List<Libro> findByTituloContainingIgnoreCase(String titulo);
}
```

Responsabilidades:
- Acceso a datos
- Query methods derivados
- `@Query` para casos complejos

### 4. Capa Entity (`entity/`)

Clases Java que representan las tablas. Anotaciones JPA.

```java
@Entity
@Table(name = "libro")
public class Libro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @ManyToOne
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;
    // ...
}
```

## Patrones de diseño aplicados

| Patrón | Dónde se aplica | Por qué |
|---|---|---|
| **MVC** | Toda la app | Separación Model / View / Controller |
| **Repository** | `repository/` | Abstrae el acceso a datos |
| **Service Layer** | `service/` | Centraliza lógica de negocio |
| **Dependency Injection** | `@Autowired` | Bajo acoplamiento, fácil testing |
| **Singleton** | Beans de Spring | Una instancia compartida |
| **Front Controller** | DispatcherServlet | Punto único de entrada HTTP |
| **DTO** | `dto/` (API REST) | No exponer la Entity directamente |
| **Strategy** | Estados de préstamo | ACTIVO/DEVUELTO/VENCIDO |

## Seguridad

Spring Security configurado con:
- `BCryptPasswordEncoder` para passwords.
- Filtros de URL por rol (`@PreAuthorize`).
- Login form-based con sesión.

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    // ...
}
```

## API REST

Endpoints `/api/**` separados de la web tradicional:

| Endpoint | Método | Devuelve |
|---|---|---|
| `/api/libros` | GET | Lista JSON de libros |
| `/api/prestamos` | POST | Crea préstamo, devuelve 201 |

Documentados con Postman (ver `postman/`).

## Internacionalización

Archivos en `src/main/resources/`:
- `messages.properties` — español (default)
- `messages_en.properties` — inglés

Usado en HTML con `th:text="#{clave}"`.
