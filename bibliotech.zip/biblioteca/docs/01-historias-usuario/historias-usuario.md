# Historias de Usuario — BiblioTech

> **Proyecto:** BiblioTech — Sistema de Gestión de Biblioteca
> **Cliente potencial:** Bibliotecas escolares, municipales y comunitarias pequeñas y medianas
> **Total de historias:** 20 (muestra mínima requerida)

## 🧭 Índice

- [HU-01 a HU-05: Módulo de Usuarios](#módulo-de-usuarios)
- [HU-06 a HU-10: Módulo de Catálogo de Libros](#módulo-de-catálogo-de-libros)
- [HU-11 a HU-14: Módulo de Préstamos (transaccional)](#módulo-de-préstamos-transaccional)
- [HU-15 a HU-17: Módulo de Multas y Devoluciones](#módulo-de-multas-y-devoluciones)
- [HU-18 a HU-20: Módulo de Reportes y API](#módulo-de-reportes-y-api)

---

## Módulo de Usuarios

### HU-01 — Registro de lector
**Como** lector nuevo,
**quiero** registrarme en el sistema con correo y contraseña,
**para** poder solicitar préstamos de libros.

**Criterios de aceptación:**
- El correo debe ser único en el sistema.
- La contraseña debe tener mínimo 8 caracteres.
- La contraseña se almacena cifrada con BCrypt.
- Al registrarse, el rol asignado por defecto es `LECTOR`.
- Se genera un número de carnet único y se muestra mensaje de confirmación.

---

### HU-02 — Inicio de sesión
**Como** usuario registrado,
**quiero** iniciar sesión con mi correo y contraseña,
**para** acceder a las funcionalidades del sistema según mi rol.

**Criterios de aceptación:**
- Si las credenciales son correctas, redirige al dashboard correspondiente.
- Si son incorrectas, muestra mensaje de error sin revelar cuál campo falló.
- Se gestiona la sesión con Spring Security.

---

### HU-03 — Cierre de sesión
**Como** usuario autenticado,
**quiero** cerrar sesión,
**para** proteger mi cuenta cuando uso una computadora compartida.

**Criterios de aceptación:**
- Al cerrar sesión, el usuario es redirigido al login.
- La sesión queda invalidada.

---

### HU-04 — Protección de rutas según rol
**Como** administrador,
**quiero** que solo los usuarios con rol `ADMIN` puedan acceder a la gestión de usuarios,
**para** mantener la seguridad del sistema.

**Criterios de aceptación:**
- Un lector que intente acceder a `/admin/**` recibe 403 Forbidden.
- Spring Security maneja la autorización con `@PreAuthorize`.

---

### HU-05 — Gestión de roles (admin)
**Como** administrador,
**quiero** asignar y cambiar roles a los usuarios,
**para** controlar quién puede hacer qué en el sistema.

**Criterios de aceptación:**
- Solo el admin ve la lista de usuarios.
- Puede cambiar el rol entre: ADMIN, BIBLIOTECARIO, LECTOR.

---

## Módulo de Catálogo de Libros

### HU-06 — Registrar libro nuevo
**Como** bibliotecario autenticado,
**quiero** registrar un libro con sus datos y autores,
**para** incorporarlo al catálogo de la biblioteca.

**Criterios de aceptación:**
- Datos requeridos: título, ISBN, editorial, año, categoría, cantidad de ejemplares.
- Se pueden asociar uno o varios autores al libro.

---

### HU-07 — Listar catálogo de libros
**Como** lector,
**quiero** ver el listado de libros disponibles,
**para** elegir cuál solicitar en préstamo.

**Criterios de aceptación:**
- Muestra título, autor, categoría y ejemplares disponibles.
- Lista en formato responsive con cards.

---

### HU-08 — Ver detalle de libro
**Como** lector o bibliotecario,
**quiero** ver el detalle completo de un libro,
**para** consultar su disponibilidad e información bibliográfica.

**Criterios de aceptación:**
- Muestra: datos bibliográficos, autores, categoría, ejemplares totales y disponibles.
- Indica si hay ejemplares disponibles para préstamo.

---

### HU-09 — Editar datos de libro
**Como** bibliotecario,
**quiero** actualizar los datos o la cantidad de ejemplares de un libro,
**para** mantener el catálogo al día.

**Criterios de aceptación:**
- Solo bibliotecario y admin pueden editar.
- Se valida que los datos sean correctos antes de guardar.

---

### HU-10 — Dar de baja un libro
**Como** bibliotecario,
**quiero** marcar un libro como inactivo,
**para** que ya no aparezca en el catálogo disponible.

**Criterios de aceptación:**
- El libro NO se borra de la BD (preserva historial de préstamos).
- Cambia un flag `activo = false`.
- Se solicita confirmación antes de la acción.

---

## Módulo de Préstamos (transaccional)

### HU-11 — Registrar un préstamo
**Como** bibliotecario,
**quiero** registrar el préstamo de un libro a un lector,
**para** controlar qué ejemplares están fuera de la biblioteca.

**Criterios de aceptación:**
- Se valida que haya ejemplares disponibles del libro.
- Se selecciona: libro, lector, fecha de préstamo y fecha de devolución esperada.
- Al crear el préstamo, se descuenta un ejemplar disponible.
- El préstamo queda en estado `ACTIVO`.

---

### HU-12 — Ver préstamos activos
**Como** bibliotecario,
**quiero** ver la lista de préstamos activos y vencidos,
**para** dar seguimiento a las devoluciones.

**Criterios de aceptación:**
- Muestra los préstamos con su estado.
- Filtros por fecha y estado (activo, vencido, devuelto).

---

### HU-13 — Registrar devolución
**Como** bibliotecario,
**quiero** registrar la devolución de un libro,
**para** actualizar la disponibilidad y cerrar el préstamo.

**Criterios de aceptación:**
- Estados válidos: ACTIVO → DEVUELTO / VENCIDO.
- Al devolver, se incrementa un ejemplar disponible.
- Si la devolución es posterior a la fecha esperada, se genera una multa automáticamente.

---

### HU-14 — Consultar mis préstamos
**Como** lector,
**quiero** consultar mis préstamos actuales y mi historial,
**para** saber qué libros tengo y cuándo debo devolverlos.

**Criterios de aceptación:**
- Solo muestra los préstamos del lector autenticado.
- Resalta los que están próximos a vencer o vencidos.

---

## Módulo de Multas y Devoluciones

### HU-15 — Calcular multa por atraso
**Como** sistema,
**quiero** calcular automáticamente la multa cuando una devolución es tardía,
**para** aplicar la penalización correspondiente.

**Criterios de aceptación:**
- La multa = días de retraso × tarifa diaria.
- Se genera al registrar la devolución tardía.
- Queda asociada 1:1 al préstamo.

---

### HU-16 — Gestionar categorías y autores (admin)
**Como** administrador,
**quiero** crear y editar categorías y autores,
**para** mantener organizado el catálogo.

**Criterios de aceptación:**
- CRUD completo (Create, Read, Update, Delete).
- No se permite eliminar una categoría o autor con libros asociados (soft delete o bloqueo).

---

### HU-17 — Registrar pago de multa
**Como** bibliotecario,
**quiero** marcar una multa como pagada,
**para** habilitar al lector para nuevos préstamos.

**Criterios de aceptación:**
- Cambia el flag `pagada = true`.
- Un lector con multas pendientes no puede solicitar nuevos préstamos.

---

## Módulo de Reportes y API

### HU-18 — Reporte de préstamos del mes
**Como** administrador,
**quiero** ver un reporte de préstamos por mes,
**para** evaluar el uso de la biblioteca.

**Criterios de aceptación:**
- Muestra: total de préstamos, libros más solicitados, multas cobradas.
- Filtros por rango de fechas.

---

### HU-19 — API: consultar libros (REST)
**Como** desarrollador de la app móvil,
**quiero** consultar el catálogo vía API REST,
**para** mostrarlo en la app del lector.

**Criterios de aceptación:**
- Endpoint `GET /api/libros`.
- Responde con JSON.
- Requiere autenticación.

---

### HU-20 — API: crear préstamo (REST)
**Como** desarrollador de la app móvil,
**quiero** registrar un préstamo vía API REST,
**para** que los lectores puedan reservar desde el móvil.

**Criterios de aceptación:**
- Endpoint `POST /api/prestamos`.
- Valida los datos en el body.
- Responde con `201 Created` y el ID del préstamo generado.
- Devuelve `400 Bad Request` si los datos son inválidos.

---

## ✅ Resumen

- **Total:** 20 historias de usuario
- **Roles cubiertos:** Lector, Bibliotecario, Administrador
- **Módulos:** Usuarios, Catálogo, Préstamos (transaccional), Multas, Reportes, API REST
- **Cumple requisito:** Módulo de Usuarios (4.2), CRUD principal (4.3), Módulo Transaccional (4.4), API REST (4.10)
