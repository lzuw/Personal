# 📝 Historias de Usuario

Las historias de usuario definen QUIÉN quiere QUÉ y PARA QUÉ. Son la base del proyecto.

## 📄 Archivos en esta carpeta

- [`historias-usuario.md`](./historias-usuario.md) — listado completo (mínimo 20)
- *(opcional)* `criterios-aceptacion.md` — criterios extendidos por historia

## 📋 Formato

Cada historia sigue el formato estándar:

> **Como** [rol del usuario]
> **quiero** [acción que puede realizar]
> **para** [beneficio que obtiene]

Y debe incluir **criterios de aceptación**: condiciones que deben cumplirse para considerar la historia terminada.

## 🎯 Roles del sistema

| Rol | Descripción |
|---|---|
| **Lector** | Socio de la biblioteca. Puede buscar libros, solicitar préstamos y consultar su historial. |
| **Bibliotecario/a** | Personal que registra préstamos, gestiona devoluciones y multas. |
| **Administrador/a** | Gestión general: usuarios, catálogo, categorías, reportes. |
