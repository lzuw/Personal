# Manual de Usuario — BiblioTech

## 1. Inicio

Acceder a `https://bibliotech.onrender.com` desde un navegador moderno (Chrome, Firefox, Edge).

> *(Aquí va una captura de la página principal del sistema)*

## 2. Registro de usuario nuevo

1. Click en **"Registrarse"** en la barra superior.
2. Completar el formulario:
   - Correo electrónico (debe ser único)
   - Contraseña (mínimo 8 caracteres)
   - Nombre y apellidos
   - Teléfono
3. Click en **"Crear cuenta"**.
4. Se inicia sesión automáticamente y se genera su carnet de socio.

## 3. Iniciar sesión

1. Click en **"Iniciar sesión"**.
2. Ingresar correo y contraseña.
3. El sistema redirige al dashboard según el rol.

## 4. Para Lectores

### 4.1 Buscar un libro

1. En el dashboard, click en **"Catálogo"**.
2. Usar el buscador por título, autor o categoría.

### 4.2 Solicitar un préstamo

1. Abrir el detalle de un libro disponible.
2. Click en **"Solicitar préstamo"**.
3. El bibliotecario confirma y registra el préstamo.
4. Se muestra la fecha de devolución esperada.

### 4.3 Ver mis préstamos

En **"Mis préstamos"** se ve el listado de libros prestados, con la fecha de devolución y si hay multas pendientes.

## 5. Para Bibliotecarios

### 5.1 Registrar un préstamo

1. Click en **"Préstamos" → "Nuevo préstamo"**.
2. Seleccionar libro y lector.
3. Definir fecha de devolución esperada.
4. Guardar (se descuenta un ejemplar disponible).

### 5.2 Registrar una devolución

1. Click sobre un préstamo activo.
2. Click en **"Registrar devolución"**.
   - Se incrementa el ejemplar disponible.
   - Si la devolución es tardía, la multa se genera automáticamente.

## 6. Para Administradores

### 6.1 Gestionar usuarios

`/admin/usuarios` — lista, edita y asigna roles.

### 6.2 Gestionar catálogo

`/admin/libros`, `/admin/categorias`, `/admin/autores` — CRUD completo.

### 6.3 Reportes

`/admin/reportes` — préstamos mensuales, libros más solicitados, multas, etc.

## 7. Cambiar de idioma

En la esquina superior derecha hay un selector ES / EN.

## 8. Soporte

📧 soporte@bibliotech.com
📱 +506 8888-9999
