# 📖 Manual de Usuario

Guía para los usuarios finales (lectores, bibliotecarios).

## 📄 Archivos en esta carpeta

| Archivo | Para quién |
|---|---|
| `manual.md` | Manual general con capturas |
| `manual-lector.md` | Específico para lectores |
| `manual-bibliotecario.md` | Específico para bibliotecarios |

## 📋 Qué incluir en cada manual

- Cómo registrarse
- Cómo iniciar sesión
- Cómo realizar las tareas comunes (con capturas)
- Solución a problemas frecuentes
- Datos de contacto del soporte

> En este repo de ejemplo `manual.md` tiene una estructura básica. En el proyecto real debe llevar capturas de pantalla del sistema funcionando.
