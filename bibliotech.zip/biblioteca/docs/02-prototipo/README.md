# 🎨 Prototipo Visual

Mockups y wireframes del sistema antes de empezar a programar.

## 📄 Archivos en esta carpeta

| Archivo | Pantalla |
|---|---|
| `01-home.png` | Página principal con menú |
| `02-login.png` | Formulario de inicio de sesión |
| `03-registro.png` | Formulario de registro |
| `04-dashboard-lector.png` | Panel del lector |
| `05-catalogo-libros.png` | Listado tipo CRUD |
| `06-formulario-libro.png` | Formulario de libro |
| `07-registrar-prestamo.png` | Pantalla transaccional |
| `08-detalle-prestamo.png` | Detalle con multa |
| `flujo-navegacion.md` | Diagrama de flujo entre pantallas |

## 🎨 Herramientas usadas

- **Figma** — diseño principal (link al proyecto público abajo)
- **Mockflow** — wireframes iniciales

## 🔗 Acceso al diseño Figma

🔗 https://www.figma.com/file/[ID-DEL-PROYECTO]/BiblioTech-Mockups
*(El link debe ser público para que el docente pueda verlo)*

## 📐 Convenciones visuales

- **Color primario:** `#1A237E` (azul biblioteca)
- **Color secundario:** `#FFC107` (amarillo cálido)
- **Tipografía:** Inter (Bootstrap default)
- **Iconos:** Bootstrap Icons
- **Espaciado:** sistema de Bootstrap (`p-3`, `m-2`, etc.)
- **Grid:** Bootstrap 5 — `col-12 col-md-6 col-lg-4` para responsive

## 📱 Pantallas mínimas requeridas (según el enunciado)

- ✅ Pantalla principal / home
- ✅ Formulario de registro y login
- ✅ Vista del CRUD principal (listado y formulario)
- ✅ Vista del módulo transaccional (registrar préstamo)
- ✅ Flujo general de navegación

> **Nota:** los PNG son **placeholders en este repo de ejemplo**. En un proyecto real, exporten desde Figma y reemplacen estos archivos.
