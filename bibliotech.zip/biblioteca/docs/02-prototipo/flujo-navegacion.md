# 🔀 Flujo de Navegación

Diagrama de cómo se conectan las pantallas del sistema.

```
                        ┌─────────────┐
                        │   HOME (/)  │
                        │  publica    │
                        └──────┬──────┘
                               │
                ┌──────────────┼──────────────┐
                ▼              ▼              ▼
         ┌──────────┐   ┌──────────┐   ┌──────────────┐
         │  /login  │   │/registro │   │  /catalogo   │
         └─────┬────┘   └─────┬────┘   │   publica    │
               │              │        └──────────────┘
               └──────┬───────┘
                      ▼
            ┌─────────────────────┐
            │   /dashboard         │
            │  (segun rol)         │
            └─────────┬────────────┘
                      │
        ┌─────────────┼─────────────┬─────────────┐
        ▼             ▼             ▼             ▼
   ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
   │ /libros │  │/prestamos│  │ /multas  │  │ /admin/* │
   │         │  │transacc. │  │          │  │(ADMIN)   │
   └────┬────┘  └────┬─────┘  └──────────┘  └──────────┘
        │            │
        ▼            ▼
   ┌────────┐  ┌──────────┐
   │CRUD    │  │/prestamos│
   │libros  │  │ nuevo    │
   └────────┘  └────┬─────┘
                    ▼
              ┌──────────────┐
              │/prestamos/   │
              │ {id} + multa │
              └──────────────┘
```

## Casos de uso principales

### 1. Lector nuevo solicita un préstamo

```
HOME → /registro → (auto-login) → /dashboard →
  /catalogo → (buscar libro) → /libros/{id} →
  SOLICITAR PRÉSTAMO → (bibliotecario confirma) →
  CONFIRMACIÓN
```

### 2. Bibliotecario registra una devolución

```
HOME → /login → /dashboard (biblio) →
  /prestamos → (préstamo activo) → /prestamos/{id} →
  REGISTRAR DEVOLUCIÓN → DEVUELTO →
  (si hay atraso) multa generada automáticamente
```

### 3. Admin genera reporte

```
HOME → /login (admin) → /dashboard →
  /admin/reportes → (filtros) →
  reporte mensual
```

## Estados de un préstamo

```
   ┌────────────┐
   │  ACTIVO    │  ← se crea
   └─────┬──────┘
         │
   ┌─────▼──────┐
   │ DEVUELTO   │  ← devolución a tiempo
   └────────────┘

   ┌────────────┐
   │  VENCIDO   │  ← pasó la fecha esperada
   └─────┬──────┘
         │
   ┌─────▼──────┐
   │ DEVUELTO   │  ← devolución tardía + multa
   └────────────┘

   ┌────────────┐
   │ CANCELADO  │  ← bibliotecario anula
   └────────────┘
```
