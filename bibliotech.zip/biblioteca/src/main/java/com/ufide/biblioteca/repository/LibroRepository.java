package com.ufide.biblioteca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ufide.biblioteca.entity.Libro;

public interface LibroRepository extends JpaRepository<Libro, Long> {
    List<Libro> findByActivoTrue();
    List<Libro> findByTituloContainingIgnoreCase(String titulo);
}
