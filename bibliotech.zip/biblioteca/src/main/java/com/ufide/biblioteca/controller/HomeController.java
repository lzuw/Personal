package com.ufide.biblioteca.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model modelo) {
        modelo.addAttribute("titulo", "BiblioTech - Bienvenido");
        return "home";
    }
}
