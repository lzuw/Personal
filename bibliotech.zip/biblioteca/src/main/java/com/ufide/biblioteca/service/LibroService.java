package com.ufide.biblioteca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufide.biblioteca.entity.Libro;
import com.ufide.biblioteca.repository.LibroRepository;

@Service
public class LibroService {

    @Autowired
    private LibroRepository repo;

    public List<Libro> listarTodos() {
        return repo.findByActivoTrue();
    }

    public Optional<Libro> buscarPorId(Long id) {
        return repo.findById(id);
    }

    public Libro guardar(Libro l) {
        return repo.save(l);
    }

    public void darDeBaja(Long id) {
        repo.findById(id).ifPresent(l -> {
            l.setActivo(false);
            repo.save(l);
        });
    }
}
